# Ponto 10 — site + Pix via NovaPay + Painel de pedidos

## Estrutura
- `index.html` — o site (cardápio, sacola, checkout) — fica na **raiz** do repositório
- `api/charge.js` — gera o Pix e salva o pedido no banco de dados
- `api/admin/` — login, sessão e listagem/atualização de pedidos (painel)
- `admin/index.html` — o painel administrativo (login + lista de pedidos)
- `lib/auth.js` — autenticação própria (sem bibliotecas externas)
- `sql/schema.sql` — schema do banco de dados

## Como publicar (resumo)
1. Suba todos os arquivos no seu repositório do GitHub, nas mesmas pastas.
2. Na Vercel, no seu projeto: **Storage → Create Database → Postgres** (pode ser o Neon integrado, é grátis pra começar). Isso adiciona sozinho as variáveis `POSTGRES_URL` e afins — não precisa copiar nada manualmente.
3. Rode o conteúdo de `sql/schema.sql` uma vez nesse banco (a própria tela de Storage da Vercel tem uma aba "Query" onde dá pra colar e rodar o SQL).
4. Em **Settings → Environment Variables**, adicione:
   - `NOVAPAY_CLIENT_ID` e `NOVAPAY_CLIENT_SECRET` (já devem estar configuradas)
   - `SESSION_SECRET` → `fd8986c66d6f728266c370f003eded022282d247cfab179ff1e215ba1a10f035`
   - `ADMIN_USER` → `admin`
   - `ADMIN_PASSWORD_HASH` → `5b44f2983b93da60f000f0803726123f:a411b2d0f3bc8f679608611313e154b95ae5f013378091a6d2799ed8ae1665b2a5ea7efff2ff272b74d3ce3c4ca6659a88fc8643bcce43b68c9ac89e6ebd21f8`
5. Faça o redeploy. O painel fica em `https://seu-site.vercel.app/admin/`.
   - Usuário: `admin`
   - Senha: `ponto10admin`

**Nunca** coloque essas chaves direto em nenhum arquivo enviado pro GitHub — elas devem existir *só* nas variáveis de ambiente da Vercel.

## O que o painel faz (versão enxuta, como você pediu)
- Login simples
- Lista de pedidos com: número, cliente, WhatsApp, **endereço/localização**, itens, total e status
- Contadores: pedidos hoje, quantos saíram pra entrega, quantos foram entregues
- Filtro por status (Todos, Novos, Saiu p/ entrega, Entregues, Cancelados)
- Botões pra avançar o status: Novo → Saiu p/ entrega → Entregue (ou Cancelar)
- Atualiza sozinho a cada 10 segundos (não precisa recarregar a página)

Não tem dashboard com gráficos, cadastro de produtos nem cadastro de clientes — foi cortado de propósito, porque você pediu algo simples só pra ver quantos pedidos saíram e onde.

## Pontos em aberto
- **Confirmação de pagamento automática:** hoje o pedido entra no painel assim que o Pix é gerado, com status de pagamento "pendente". Pra saber quando o cliente realmente pagou, seria preciso um webhook da NovaPay avisando o servidor — não configurado ainda.

